"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock } from "lucide-react"
import { hasValidCredentials, supabase } from "@/lib/supabase"

interface Match {
  id: string
  home_team: string
  away_team: string
  date: string
  time: string
  home_logo?: string
  away_logo?: string
}

export default function MatchSchedule() {
  const [matches, setMatches] = useState<Match[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadMatches()
  }, [])

  const loadMatches = async () => {
    setIsLoading(true)
    try {
      if (!hasValidCredentials) {
        // Use mock data when Supabase is not configured
        const mockMatches: Match[] = [
          {
            id: "1",
            home_team: "Barcelona",
            away_team: "Real Madrid",
            date: "2024-06-15",
            time: "20:00",
            home_logo: "/placeholder.svg?height=48&width=48",
            away_logo: "/placeholder.svg?height=48&width=48",
          },
          {
            id: "2",
            home_team: "Manchester City",
            away_team: "Liverpool",
            date: "2024-06-16",
            time: "16:30",
            home_logo: "/placeholder.svg?height=48&width=48",
            away_logo: "/placeholder.svg?height=48&width=48",
          },
          {
            id: "3",
            home_team: "PSG",
            away_team: "Bayern Munich",
            date: "2024-06-17",
            time: "21:00",
            home_logo: "/placeholder.svg?height=48&width=48",
            away_logo: "/placeholder.svg?height=48&width=48",
          },
          {
            id: "4",
            home_team: "Inter Miami",
            away_team: "LA Galaxy",
            date: "2024-06-18",
            time: "19:30",
            home_logo: "/placeholder.svg?height=48&width=48",
            away_logo: "/placeholder.svg?height=48&width=48",
          },
          {
            id: "5",
            home_team: "Deportivo Saprissa",
            away_team: "Alajuelense",
            date: "2024-06-19",
            time: "20:00",
            home_logo: "/placeholder.svg?height=48&width=48",
            away_logo: "/placeholder.svg?height=48&width=48",
          },
        ]

        setMatches(mockMatches)
        setIsLoading(false)
        return
      }

      // Get the latest match schedule from json_uploads
      const { data, error } = await supabase
        .from("json_uploads")
        .select("*")
        .eq("type", "match_schedule")
        .order("created_at", { ascending: false })
        .limit(1)

      if (error) throw error

      if (data && data.length > 0) {
        setMatches(data[0].data)
      }
    } catch (error) {
      console.error("Error loading matches:", error)
    }
    setIsLoading(false)
  }

  // Group matches by date
  const matchesByDate = matches.reduce(
    (acc, match) => {
      if (!acc[match.date]) {
        acc[match.date] = []
      }
      acc[match.date].push(match)
      return acc
    },
    {} as Record<string, Match[]>,
  )

  // Sort dates
  const sortedDates = Object.keys(matchesByDate).sort()

  // Format date for display
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
    return new Date(dateString).toLocaleDateString("es-ES", options)
  }

  if (isLoading) {
    return (
      <Card className="bg-white/5 backdrop-blur-xl border border-white/10">
        <CardContent className="p-6 flex justify-center items-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-amber-500"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-white/5 backdrop-blur-xl border border-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center space-x-2">
          <Calendar className="w-6 h-6 text-amber-400" />
          <span>Programación de Partidos</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {matches.length === 0 ? (
          <div className="text-center py-8 text-white/70">
            <p>No hay partidos programados actualmente.</p>
          </div>
        ) : (
          <Tabs defaultValue={sortedDates[0]} className="w-full">
            <TabsList className="grid grid-cols-3 md:grid-cols-5 mb-4 bg-white/5 border border-white/10">
              {sortedDates.map((date) => (
                <TabsTrigger
                  key={date}
                  value={date}
                  className="text-xs md:text-sm data-[state=active]:bg-amber-500/20 data-[state=active]:text-amber-400"
                >
                  {new Date(date).toLocaleDateString("es-ES", { weekday: "short", day: "numeric" })}
                </TabsTrigger>
              ))}
            </TabsList>

            {sortedDates.map((date) => (
              <TabsContent key={date} value={date} className="space-y-4">
                <h3 className="text-lg font-medium text-amber-400 mb-4">{formatDate(date)}</h3>
                <div className="space-y-3">
                  {matchesByDate[date].map((match) => (
                    <div
                      key={match.id}
                      className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 hover:bg-white/10 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3 flex-1">
                          <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center shadow-md">
                            <img
                              src={match.home_logo || "/placeholder.svg?height=32&width=32"}
                              alt={match.home_team}
                              className="w-8 h-8 rounded-full object-contain"
                              onError={(e) => {
                                e.currentTarget.style.display = "none"
                                e.currentTarget.nextElementSibling!.style.display = "flex"
                              }}
                            />
                            <div className="hidden w-8 h-8 bg-neutral-700 rounded-full items-center justify-center">
                              <span className="text-xs font-bold text-white">{match.home_team.substring(0, 2)}</span>
                            </div>
                          </div>
                          <span className="text-white font-medium">{match.home_team}</span>
                        </div>
                        <div className="flex flex-col items-center px-4">
                          <span className="text-amber-400 text-xs">VS</span>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="w-4 h-4 text-amber-400" />
                            <span className="text-white text-sm">{match.time}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3 justify-end flex-1">
                          <span className="text-white font-medium">{match.away_team}</span>
                          <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center shadow-md">
                            <img
                              src={match.away_logo || "/placeholder.svg?height=32&width=32"}
                              alt={match.away_team}
                              className="w-8 h-8 rounded-full object-contain"
                              onError={(e) => {
                                e.currentTarget.style.display = "none"
                                e.currentTarget.nextElementSibling!.style.display = "flex"
                              }}
                            />
                            <div className="hidden w-8 h-8 bg-neutral-700 rounded-full items-center justify-center">
                              <span className="text-xs font-bold text-white">{match.away_team.substring(0, 2)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}
      </CardContent>
    </Card>
  )
}
