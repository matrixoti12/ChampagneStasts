"use client"

import { useState } from "react"
import type { Player } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Star, Users, Trophy, Zap, Crown, Flame } from "lucide-react"

interface PlayerCardProps {
  player: Player
  onVote: (playerId: string) => void
  canVote: boolean
}

export default function PlayerCard({ player, onVote, canVote }: PlayerCardProps) {
  const [isVoting, setIsVoting] = useState(false)
  const [imageError, setImageError] = useState(false)

  const designStyles = {
    glass: {
      card: "bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-xl border border-white/20 shadow-2xl",
      photo: "rounded-2xl border-4 border-white/30 shadow-2xl backdrop-blur-sm",
      stats: "bg-white/10 backdrop-blur-xl border border-white/20",
      text: "text-white",
      accent: "text-cyan-300",
      bg: "bg-gradient-to-br from-purple-600 via-blue-600 to-teal-600",
    },
    elite: {
      card: "bg-gradient-to-br from-gray-900 via-gray-800 to-black border-2 border-yellow-400/50 shadow-2xl shadow-yellow-400/20",
      photo: "rounded-3xl border-4 border-gradient-to-r border-yellow-400 shadow-2xl shadow-yellow-400/30",
      stats: "bg-gradient-to-r from-yellow-600/20 to-orange-600/20 backdrop-blur-sm border border-yellow-400/30",
      text: "text-white",
      accent: "text-yellow-400",
      bg: "bg-black",
    },
    holographic: {
      card: "bg-gradient-to-br from-pink-500/20 via-purple-500/20 to-cyan-500/20 backdrop-blur-xl border-2 border-transparent bg-clip-padding shadow-2xl",
      photo:
        "rounded-full border-4 border-transparent bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 p-1 shadow-2xl",
      stats:
        "bg-gradient-to-r from-pink-500/30 via-purple-500/30 to-cyan-500/30 backdrop-blur-xl border border-white/20",
      text: "text-white",
      accent: "text-pink-300",
      bg: "bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900",
    },
    diamond: {
      card: "bg-gradient-to-br from-emerald-100 to-teal-100 border-4 border-emerald-400 shadow-2xl shadow-emerald-400/30",
      photo: "transform rotate-45 border-4 border-emerald-600 shadow-2xl shadow-emerald-600/40",
      stats: "bg-gradient-to-r from-emerald-400/90 to-teal-400/90 border border-emerald-600",
      text: "text-emerald-900",
      accent: "text-emerald-700",
      bg: "bg-gradient-to-br from-emerald-50 to-teal-50",
    },
    cosmic: {
      card: "bg-gradient-to-br from-indigo-900/80 via-purple-900/80 to-pink-900/80 backdrop-blur-xl border border-purple-400/30 shadow-2xl",
      photo: "rounded-2xl border-4 border-purple-400 shadow-2xl shadow-purple-400/50",
      stats:
        "bg-gradient-to-r from-indigo-600/40 via-purple-600/40 to-pink-600/40 backdrop-blur-xl border border-purple-400/30",
      text: "text-white",
      accent: "text-purple-300",
      bg: "bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900",
    },
    fire: {
      card: "bg-gradient-to-br from-red-600/90 via-orange-500/90 to-yellow-500/90 border-2 border-red-400 shadow-2xl shadow-red-500/40",
      photo: "rounded-xl border-4 border-yellow-300 shadow-2xl shadow-orange-500/50",
      stats: "bg-gradient-to-r from-red-700/80 to-orange-700/80 border border-yellow-400",
      text: "text-white",
      accent: "text-yellow-200",
      bg: "bg-gradient-to-br from-red-800 to-orange-800",
    },
  }

  const style = designStyles[player.card_style] || designStyles.glass

  const getRatingIcon = () => {
    if (player.card_style === "elite") return Crown
    if (player.card_style === "fire") return Flame
    if (player.card_style === "cosmic") return Zap
    return Star
  }

  const RatingIcon = getRatingIcon()

  const handleVote = async () => {
    setIsVoting(true)
    await onVote(player.id)
    setIsVoting(false)
  }

  const handleImageError = () => {
    setImageError(true)
  }

  return (
    <div className={`${style.bg} p-1 rounded-3xl transform hover:scale-105 transition-all duration-300`}>
      <div className={`w-72 h-[480px] rounded-3xl p-6 ${style.card} relative overflow-hidden`}>
        {/* Efecto de brillo para holographic */}
        {player.card_style === "holographic" && (
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -skew-x-12 animate-pulse" />
        )}

        {/* Logos de liga y equipo */}
        <div className="flex justify-between items-start mb-4">
          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-white/95 flex items-center justify-center shadow-xl ring-2 ring-white/50">
              {player.league_logo_url ? (
                <img
                  src={player.league_logo_url || "/placeholder.svg"}
                  alt="Liga"
                  className="w-10 h-10 rounded-full object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling!.style.display = "flex"
                  }}
                />
              ) : (
                <Trophy className="w-6 h-6 text-blue-500" />
              )}
              <div className="hidden w-10 h-10 bg-blue-500 rounded-full items-center justify-center">
                <Trophy className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-white/95 flex items-center justify-center shadow-xl ring-2 ring-white/50">
              {player.team_logo_url ? (
                <img
                  src={player.team_logo_url || "/placeholder.svg"}
                  alt="Equipo"
                  className="w-10 h-10 rounded-full object-contain"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling!.style.display = "flex"
                  }}
                />
              ) : (
                <Users className="w-6 h-6 text-red-500" />
              )}
              <div className="hidden w-10 h-10 bg-red-500 rounded-full items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        </div>

        {/* Foto del jugador */}
        <div className="flex justify-center mb-6">
          {player.card_style === "holographic" ? (
            <div className={style.photo}>
              <div className="w-36 h-36 rounded-full overflow-hidden bg-gray-800 flex items-center justify-center">
                {!imageError ? (
                  <img
                    src={player.photo || "/placeholder.svg?height=144&width=144"}
                    alt={player.name}
                    className="w-full h-full object-cover"
                    onError={handleImageError}
                  />
                ) : (
                  <Users className="w-16 h-16 text-white" />
                )}
              </div>
            </div>
          ) : (
            <div
              className={`w-36 h-36 overflow-hidden ${style.photo} ${
                player.card_style === "diamond" ? "bg-gray-800" : "bg-gray-800"
              }`}
            >
              {!imageError ? (
                <img
                  src={player.photo || "/placeholder.svg?height=144&width=144"}
                  alt={player.name}
                  className={`w-full h-full object-cover ${player.card_style === "diamond" ? "-rotate-45 scale-125" : ""}`}
                  onError={handleImageError}
                />
              ) : (
                <div
                  className={`w-full h-full bg-gray-800 flex items-center justify-center ${
                    player.card_style === "diamond" ? "-rotate-45" : ""
                  }`}
                >
                  <Users className="w-16 h-16 text-white" />
                </div>
              )}
            </div>
          )}
        </div>

        {/* Nombre del jugador */}
        <div className="text-center mb-5">
          <h3 className={`text-2xl font-black tracking-wide ${style.text} drop-shadow-lg`}>
            {player.name.toUpperCase()}
          </h3>
          <div className={`text-xs font-semibold ${style.accent} tracking-widest mt-1`}>
            {player.position === "goalkeeper" ? "PORTERO" : "JUGADOR ESTRELLA"}
          </div>
        </div>

        {/* Estadísticas */}
        <div className={`rounded-2xl p-4 ${style.stats} shadow-lg mb-4`}>
          <div className="grid grid-cols-3 gap-4">
            {player.position === "field" ? (
              <>
                <div className="text-center">
                  <div className={`text-xs font-bold ${style.text} opacity-80 tracking-wider`}>GOLES</div>
                  <div className={`text-2xl font-black ${style.text} mt-1`}>{player.goals || 0}</div>
                </div>

                <div className="text-center">
                  <div className={`text-xs font-bold ${style.text} opacity-80 tracking-wider`}>MVP</div>
                  <div className={`text-2xl font-black ${style.text} mt-1`}>{player.mvp_count}</div>
                </div>

                <div className="text-center">
                  <div className={`text-xs font-bold ${style.text} opacity-80 tracking-wider`}>ASIST</div>
                  <div className={`text-2xl font-black ${style.text} mt-1`}>{player.assists || 0}</div>
                </div>
              </>
            ) : (
              <>
                <div className="text-center">
                  <div className={`text-xs font-bold ${style.text} opacity-80 tracking-wider`}>SAVES</div>
                  <div className={`text-2xl font-black ${style.text} mt-1`}>{player.saves || 0}</div>
                </div>

                <div className="text-center">
                  <div className={`text-xs font-bold ${style.text} opacity-80 tracking-wider`}>MVP</div>
                  <div className={`text-2xl font-black ${style.text} mt-1`}>{player.mvp_count}</div>
                </div>

                <div className="text-center">
                  <div className={`text-xs font-bold ${style.text} opacity-80 tracking-wider`}>CLEAN</div>
                  <div className={`text-2xl font-black ${style.text} mt-1`}>0</div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Rating con iconos específicos */}
        <div className="flex justify-center mb-4 space-x-1">
          {[...Array(5)].map((_, i) => (
            <RatingIcon
              key={i}
              className={`w-5 h-5 ${
                i < (player.rating || 3) ? `${style.accent} fill-current drop-shadow-lg` : `${style.text} opacity-30`
              }`}
            />
          ))}
        </div>

        {/* Botón de votación */}
        {canVote && (
          <Button
            onClick={handleVote}
            disabled={isVoting}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-700 hover:from-amber-600 hover:to-amber-800 text-white font-bold py-2 rounded-xl shadow-lg border-none"
          >
            {isVoting ? "Votando..." : "Votar MVP"}
          </Button>
        )}
      </div>
    </div>
  )
}
