"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Trophy } from "lucide-react"
import { hasValidCredentials, supabase } from "@/lib/supabase"
import type { Standings } from "@/lib/types"

export default function TeamStandings() {
  const [standings, setStandings] = useState<Standings[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadStandings()
  }, [])

  const loadStandings = async () => {
    setIsLoading(true)
    try {
      if (!hasValidCredentials) {
        // Use mock data when Supabase is not configured
        const mockStandings: Standings[] = [
          {
            id: "1",
            team_name: "PSG",
            played: 24,
            won: 19,
            drawn: 2,
            lost: 3,
            goals_for: 65,
            goals_against: 18,
            goal_difference: 47,
            points: 59,
          },
          {
            id: "2",
            team_name: "Manchester City",
            played: 24,
            won: 18,
            drawn: 4,
            lost: 2,
            goals_for: 72,
            goals_against: 22,
            goal_difference: 50,
            points: 58,
          },
          {
            id: "3",
            team_name: "Liverpool",
            played: 24,
            won: 16,
            drawn: 6,
            lost: 2,
            goals_for: 68,
            goals_against: 25,
            goal_difference: 43,
            points: 54,
          },
          {
            id: "4",
            team_name: "Real Madrid",
            played: 24,
            won: 17,
            drawn: 3,
            lost: 4,
            goals_for: 58,
            goals_against: 28,
            goal_difference: 30,
            points: 54,
          },
          {
            id: "5",
            team_name: "Deportivo Saprissa",
            played: 24,
            won: 14,
            drawn: 6,
            lost: 4,
            goals_for: 48,
            goals_against: 28,
            goal_difference: 20,
            points: 48,
          },
        ]

        setStandings(mockStandings)
        setIsLoading(false)
        return
      }

      const { data, error } = await supabase.from("standings").select("*").order("points", { ascending: false })

      if (error) throw error
      setStandings(data || [])
    } catch (error) {
      console.error("Error loading standings:", error)
    }
    setIsLoading(false)
  }

  if (isLoading) {
    return (
      <Card className="bg-white/5 backdrop-blur-xl border border-white/10">
        <CardContent className="p-6 flex justify-center items-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-amber-500"></div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-white/5 backdrop-blur-xl border border-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center space-x-2">
          <Trophy className="w-6 h-6 text-amber-400" />
          <span>Tabla de Posiciones</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-amber-400/80 border-b border-white/10">
                <th className="text-left py-3 px-2">#</th>
                <th className="text-left py-3 px-2">Equipo</th>
                <th className="text-center py-3 px-2">PJ</th>
                <th className="text-center py-3 px-2">G</th>
                <th className="text-center py-3 px-2">E</th>
                <th className="text-center py-3 px-2">P</th>
                <th className="text-center py-3 px-2">GF</th>
                <th className="text-center py-3 px-2">GC</th>
                <th className="text-center py-3 px-2">DG</th>
                <th className="text-center py-3 px-2">PTS</th>
              </tr>
            </thead>
            <tbody>
              {standings.map((team, index) => (
                <tr
                  key={team.id}
                  className={`border-b border-white/5 hover:bg-white/5 transition-colors ${
                    index < 4 ? "bg-gradient-to-r from-amber-500/10 to-transparent" : ""
                  }`}
                >
                  <td className="py-3 px-2 text-white">
                    <div className="flex items-center">
                      <span className="font-bold">{index + 1}</span>
                      {index === 0 && <Trophy className="w-4 h-4 ml-1 text-amber-400" />}
                    </div>
                  </td>
                  <td className="py-3 px-2 text-white font-medium">{team.team_name}</td>
                  <td className="py-3 px-2 text-white text-center">{team.played}</td>
                  <td className="py-3 px-2 text-white text-center">{team.won}</td>
                  <td className="py-3 px-2 text-white text-center">{team.drawn}</td>
                  <td className="py-3 px-2 text-white text-center">{team.lost}</td>
                  <td className="py-3 px-2 text-white text-center">{team.goals_for}</td>
                  <td className="py-3 px-2 text-white text-center">{team.goals_against}</td>
                  <td className="py-3 px-2 text-white text-center">{team.goal_difference}</td>
                  <td className="py-3 px-2 text-amber-400 text-center font-bold">{team.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  )
}
